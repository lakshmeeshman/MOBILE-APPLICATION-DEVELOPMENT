package com.example.madexp7datepickeremployee;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText ed1, ed2;
    DatePicker datePicker;
    Button buttonSubmit;
    ImageView iv1;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.ed1);
        ed2 = findViewById(R.id.ed2);
        datePicker = findViewById(R.id.datePicker);
        buttonSubmit = findViewById(R.id.btn1);
        iv1 = findViewById(R.id.iv1);

        iv1.setImageResource(R.drawable.img1);


        buttonSubmit.setOnClickListener(v -> {

            String name = ed1.getText().toString();
            String department = ed2.getText().toString();
            int day = datePicker.getDayOfMonth();
            int month = datePicker.getMonth() + 1;
            int year = datePicker.getYear();

            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("name", name);
            intent.putExtra("department", department);
            intent.putExtra("day", day);
            intent.putExtra("month", month);
            intent.putExtra("year", year);
            startActivity(intent);
        });
    }
}