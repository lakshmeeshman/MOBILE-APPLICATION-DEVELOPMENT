package com.example.madexp7datepickeremployee;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);
        EditText e1 = findViewById(R.id.ed1);
        Button b1 = findViewById(R.id.btn1);
        Button b2 = findViewById(R.id.btn2);
        TextView tv = findViewById(R.id.tv1);

        String name = getIntent().getStringExtra("name");
        String department = getIntent().getStringExtra("department");
        int day = getIntent().getIntExtra("day", 0);
        int month = getIntent().getIntExtra("month", 0);
        int year = getIntent().getIntExtra("year", 0);

        String employeeData = name + " " + department + " " + day + "/" + month + "/" + year;

        b1.setOnClickListener(v -> {
            String projectName = e1.getText().toString();
            String fileContent = employeeData + "\nProject: " + projectName;

            try (FileOutputStream fos = openFileOutput("employee_data.txt", Context.MODE_PRIVATE)) {
                fos.write(fileContent.getBytes());
                Toast.makeText(SecondActivity.this, "File saved", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                Toast.makeText(SecondActivity.this, "Error saving file", Toast.LENGTH_LONG).show();
            }
        });

        b2.setOnClickListener(v -> {
            try (FileInputStream fis = openFileInput("employee_data.txt")) {
                int c;
                StringBuilder temp = new StringBuilder();

                while ((c = fis.read()) != -1) {
                    temp.append((char) c);
                }

                tv.setText(temp.toString());
                Toast.makeText(SecondActivity.this, "File read", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                Toast.makeText(SecondActivity.this, "Error reading file", Toast.LENGTH_LONG).show();
            }
        });
    }
}